# yolo_koala_kangaroo > Original
https://universe.roboflow.com/nyp-cwjfs/yolo_koala_kangaroo

Provided by a Roboflow user
License: CC BY 4.0

